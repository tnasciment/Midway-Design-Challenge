function getName(){
  var nameElement = document.querySelector('#name');
  var name = nameElement.value;
  
  console.log(name);

}

